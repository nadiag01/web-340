/**
<<<<<<< HEAD
 * Author:Nadia Gainer
 * Date: 03/22/24
 * File Name: 
=======
 * Author:
 * Date:
 * File Name:
>>>>>>> 84a094bd7c5a4b60280af824138277b4468a25b5
 * Description:
*/

"use strict";

<<<<<<< HEAD
// TODO: Implement the weight conversion logic here

function weightConverter(valNum) {
  document.getElementById("outputGrams").innerHTML = valNum / 0.0022046;
  }

  
=======
// TODO: Implement the weight conversion logic here
>>>>>>> 84a094bd7c5a4b60280af824138277b4468a25b5
